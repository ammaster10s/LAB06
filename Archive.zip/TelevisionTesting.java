import javax.swing.*;
import java.awt.*;
public class TelevisionTesting {
	public static void main(String[] args) {
		
		Television myTelevision = new Television("My Television");
        
        

	}
}